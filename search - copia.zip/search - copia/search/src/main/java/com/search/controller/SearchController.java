package com.search.controller;

import com.search.model.Search;
import com.search.model.ServiceSearch;
import com.search.repository.SearchRepository;
import com.search.repository.ServiceSearchRepository;
import com.search.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/servicios")
public class SearchController {

    @Autowired
    private SearchRepository searchRepository;

    @Autowired
    private SearchService searchService;

    @Autowired
    private ServiceSearchRepository serviceSearchRepository;

    // Crear una nueva búsqueda
    @PostMapping
    public ResponseEntity<Search> crearBusqueda(@RequestBody Search search) {
        Search guardada = searchService.save(search);
        return ResponseEntity.ok(guardada);
    }

    // Obtener búsqueda por RUT
    @GetMapping("/{rut}")
    public ResponseEntity<Search> obtenerPorRut(@PathVariable String rut) {
        return searchRepository.findById(rut)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Actualizar búsqueda
    @PutMapping("/update/{rut}")
    public ResponseEntity<Search> actualizarBusqueda(@PathVariable String rut, @RequestBody Search actualizada) {
        if (!searchRepository.existsById(rut)) {
            return ResponseEntity.notFound().build();
        }
        actualizada.setRut(rut); // asegurarse de que no cambie el RUT
        return ResponseEntity.ok(searchRepository.save(actualizada));
    }

    // Eliminar búsqueda
    @DeleteMapping("/delete/{rut}")
    public ResponseEntity<Void> eliminarBusqueda(@PathVariable String rut) {
        if (searchRepository.existsById(rut)) {
            searchRepository.deleteById(rut);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/buscar/category/{category}")
    public List<Search> findByCategory(@PathVariable String category) {
        return searchRepository.findByCategory(category);
    }

    @GetMapping("/buscar/name/{name}")
    public List<Search> findByNameContainingIgnoreCase(@PathVariable String name) {
        return searchRepository.findByNameContainingIgnoreCase(name);
    }

    @GetMapping("/buscar")
    public List<Search> buscarTodo() {
        return searchRepository.findAll();
    }

    /// Service Search
    @GetMapping("/service-searches/all")
    public List<ServiceSearch> getAllServiceSearches() {
        return serviceSearchRepository.findAll();
    }

    @GetMapping("/service-searches/city/{city}")
    public List<ServiceSearch> getServiceSearchesByCity(@PathVariable String city) {
        return serviceSearchRepository.findByCity(city);
    }

    @GetMapping("/service-searches/search/{searchRut}")
    public List<ServiceSearch> getServiceSearchesBySearchRut(@PathVariable String searchRut) {
        return serviceSearchRepository.findBySearchRut(searchRut);
    }

    @PostMapping("/service-searches")
    public ServiceSearch createServiceSearch(@RequestBody ServiceSearch serviceSearch) {
        return serviceSearchRepository.save(serviceSearch);
    }
}
