package com.search.model;



import jakarta.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "search")
public class Search {

    @Id
    @Column(unique = true, length = 13, nullable = false)
    private String rut;

    @Column(nullable = false)

    private String name;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private String description;

}
