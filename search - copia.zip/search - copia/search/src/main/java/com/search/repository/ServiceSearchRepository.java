package com.search.repository;

import com.search.model.ServiceSearch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceSearchRepository extends JpaRepository<ServiceSearch, Long> {
    List<ServiceSearch> findByCity(String city);
    List<ServiceSearch> findBySearchRut(String rut); // actualizado para usar String rut
}
