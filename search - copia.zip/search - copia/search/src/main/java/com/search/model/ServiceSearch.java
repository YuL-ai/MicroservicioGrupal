package com.search.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "service_search")
public class ServiceSearch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private String date;

    @ManyToOne
    @JoinColumn(
            name = "search_rut",          // nombre de la FK en la tabla service_search
            referencedColumnName = "rut", // referencia al campo rut de Search
            nullable = false
    )
    private Search search;
}
