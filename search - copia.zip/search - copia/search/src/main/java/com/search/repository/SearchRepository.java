package com.search.repository;

import com.search.model.Search;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SearchRepository extends JpaRepository<Search, String> {

        List<Search> findByCategory(String categoria);
        List<Search> findByNameContainingIgnoreCase(String name);
}
