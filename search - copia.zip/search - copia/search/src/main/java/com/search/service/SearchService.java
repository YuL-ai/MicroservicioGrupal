package com.search.service;

import com.search.model.Search;
import com.search.repository.SearchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SearchService {

    @Autowired
    private SearchRepository searchRepository;

    public List<Search> findAll() {
        return searchRepository.findAll();
    }

    public Optional<Search> findByRut(String rut) {
        return searchRepository.findById(rut);
    }

    public List<Search> findByCategory(String categoria) {
        return searchRepository.findByCategory(categoria);
    }

    public List<Search> searchByName(String nombre) {
        return searchRepository.findByNameContainingIgnoreCase(nombre);
    }

    public Search save(Search search) {
        return searchRepository.save(search);
    }

    public void deleteByRut(String rut) {
        searchRepository.deleteById(rut);
    }
}

